# AnonChat-tgbot
Anonymous chat bot for Telegram
